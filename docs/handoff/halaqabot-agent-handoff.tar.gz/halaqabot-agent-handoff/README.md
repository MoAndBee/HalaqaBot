Read docs/agent-environment-handoff.md first. Apply the patch only to its pinned base, not on top of the current migration branch. Obtain credentials privately.
